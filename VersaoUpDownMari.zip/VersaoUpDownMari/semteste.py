import pygame
import random
import time

# Inicializar o Pygame
pygame.init()

# Definindo as cores
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
CINZA = (46,46,46)
AZUL = (0, 0, 255)
VERDE = (0, 128, 0)
VERMELHO = (255, 0, 0)
VERMELHO_TIMER = (208, 0, 0)

# Configurações da tela 
LARGURA_TELA = 800 
ALTURA_TELA = 700  
tela = pygame.display.set_mode((LARGURA_TELA, ALTURA_TELA))
pygame.display.set_caption("Associa Imagem")

#Clock
clock = pygame.time.Clock()

# Fontes
fonte_pontos = pygame.font.Font("Montserrat-Regular.ttf", 35)
fonte = pygame.font.Font("Montserrat-Regular.ttf", 25)

# Carregar música e sons
pygame.mixer.music.load("musica_fundo.mp3")  
pygame.mixer.music.set_volume(0.2)  
pygame.mixer.music.play(-1)  

# Sons de feedback
som_acerto = pygame.mixer.Sound("acerto.wav")  
som_erro = pygame.mixer.Sound("erro.wav")  

# Lista de imagens e animais
imagens = [
    {"imagem": "imagem1.png", "palavra": "Macaco"},
    {"imagem": "imagem2.png", "palavra": "Rinoceronte"},
    {"imagem": "imagem3.png", "palavra": "Leão"},
    {"imagem": "imagem4.png", "palavra": "Elefante"},
    {"imagem": "imagem5.png", "palavra": "Onça"},
    {"imagem": "imagem6.png", "palavra": "Cavalo"},
    {"imagem": "imagem7.png", "palavra": "Avestruz"},   
    {"imagem": "imagem8.png", "palavra": "Zebra"},
    {"imagem": "imagem9.png", "palavra": "Hipopotamo"},   
    {"imagem": "imagem10.png", "palavra": "Porco"}, 
    {"imagem": "imagem11.png", "palavra": "Girafa"},
    {"imagem": "imagem12.png", "palavra": "Canguru"},
    
]

# Função para desenhar o timer
def desenhar_timer(t, tempo_maximo):
    if t<4:
        cor_timer = VERMELHO_TIMER
    else:
        cor_timer = VERDE
    pygame.draw.rect(tela, CINZA, (LARGURA_TELA - 160, 20, 150, 30)) 
    pygame.draw.rect(tela, cor_timer, (LARGURA_TELA - 160, 20, (150 * t) / tempo_maximo, 30))
    timer_text = fonte.render(f"Tempo: {t}", True, BRANCO)
    tela.blit(timer_text, (LARGURA_TELA - 150, 18))

# Função para desenhar setas de direção
def desenhar_seta(x, y, direcao):
    if direcao == 'up':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 10, y + 20), (x + 10, y + 20)])
    elif direcao == 'down':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 10, y - 20), (x + 10, y - 20)])
    elif direcao == 'left':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x + 20, y - 10), (x + 20, y + 10)])
    elif direcao == 'right':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 20, y - 10), (x - 20, y + 10)])

# Função para desenhar a caixa para a imagem
def desenhar_caixa_imagem():
    pygame.draw.rect(tela, AZUL, (LARGURA_TELA // 2 - 160, 10, 320, 320), 5)  # Caixa encostada no topo

def tela_final(pontos, multiplicador):
    opcoes = ["Jogar novamente", "Próximo nível", "Voltar aos níveis", "Sair"] if multiplicador < 3 else ["Jogar novamente", "Voltar aos níveis", "Sair"]

    escolha = navegar_opcoes(
        opcoes,
        f"Fim do Jogo! Pontuação: {pontos}",
        cor_titulo=VERDE,
    )
    
    if escolha == 0:  # Jogar novamente
        return "reiniciar"
    elif escolha == 1 and multiplicador < 3:  # Próximo nível
        return "proximo_nivel"
    elif (escolha == 2 and multiplicador < 3) or (escolha == 1 and multiplicador == 3):  # Voltar aos níveis
        return "menu_niveis"
    elif (escolha == 3 and multiplicador < 3) or (escolha == 2 and multiplicador == 3):  # Sair
        pygame.quit()
        exit()


def navegar_opcoes(opcoes, titulo, cor_titulo=AZUL):
    tela.fill(BRANCO)
    titulo_texto = fonte_pontos.render(titulo, True, cor_titulo)
    tela.blit(titulo_texto, (LARGURA_TELA // 2 - titulo_texto.get_width() // 2, ALTURA_TELA // 4))

    selecionado = 0
    rodando = True

    while rodando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_DOWN:
                    selecionado = (selecionado + 1) % len(opcoes)
                elif evento.key == pygame.K_UP:
                    selecionado = (selecionado - 1) % len(opcoes)
                elif evento.key == pygame.K_SPACE:
                    return selecionado

        # Desenhar as opções
        for i, opcao in enumerate(opcoes):
            cor = VERDE if i == selecionado else AZUL
            texto = fonte.render(opcao, True, cor)
            tela.blit(
                texto,
                (LARGURA_TELA // 2 - texto.get_width() // 2, ALTURA_TELA // 2 + i * 50),
            )

        pygame.display.flip()
        clock.tick(30)

# Função para desenhar o menu inicial
def menu_inicial():
    opcoes = ["Começar o jogo", "Sair"]
    escolha = navegar_opcoes(opcoes, "Jogo de Associação")
    if escolha == 0:
        menu_dificuldade()
    elif escolha == 1:
        pygame.quit()
        exit()

def menu_pause():
    opcoes = ["Continuar", "Voltar ao menu", "Sair"]
    escolha = navegar_opcoes(opcoes, "PAUSA")
    if escolha == 0:
        return "continuar"  # Volta ao jogo
    elif escolha == 1:
        return "menu_niveis"  # Volta ao menu de níveis
    elif escolha == 2:
        pygame.quit()  # Fecha o jogo
        exit()

# Função para desenhar o menu de seleção de dificuldade
def menu_dificuldade():
    opcoes = ["Fácil (30 segundos)", "Médio (15 segundos)", "Difícil (5 segundos)"]
    escolha = navegar_opcoes(opcoes, "Escolha a dificuldade")
    if escolha == 0:
        jogo(30, 1)
        #return 30, 1  # Fácil
    elif escolha == 1:
        jogo(15, 2)
        #return 15, 2  # Médio
    elif escolha == 2:
        jogo(5, 3)
        #return 5, 3  # Difícil

# Atualização na função para desenhar as opções
def jogo(tempo_maximo, multiplicador):
    pontos = 0
    rodada = 0
    imagens_usadas = []
    opcoes = []
    ultima_mudanca = 0
    tempo_mudanca = 0

    while rodada < 10:
        rodada += 1
        rodada_restante = 10 - rodada
        tela.fill(BRANCO)

        # Selecionar uma imagem aleatória
        imagem_atual = random.choice([img for img in imagens if img not in imagens_usadas])
        imagens_usadas.append(imagem_atual)

        palavra_correta = imagem_atual["palavra"]
        opcoes = random.sample([img["palavra"] for img in imagens if img != imagem_atual], 3)
        opcoes.append(palavra_correta)
        random.shuffle(opcoes)

        desenhar_caixa_imagem()

        # Exibir a imagem
        img = pygame.image.load(imagem_atual["imagem"])
        img = pygame.transform.scale(img, (300, 300))  # Redimensiona
        tela.blit(img, (LARGURA_TELA // 2 - 150, 10))

        x_centro = LARGURA_TELA // 2
        y_centro = ALTURA_TELA - 150  # Movendo as opções para baixo

        opcao_textos = []
        for i, opcao in enumerate(opcoes):
            texto = fonte.render(opcao, True, AZUL)
            opcao_textos.append(texto)

        # Desenhar as opções
        tela.blit(opcao_textos[0], (x_centro - opcao_textos[0].get_width() // 2, y_centro - 200))
        desenhar_seta(x_centro, y_centro - 150, 'up')

        tela.blit(opcao_textos[1], (x_centro - 200 - opcao_textos[1].get_width() // 2, y_centro - 50))
        desenhar_seta(x_centro - 200, y_centro - 100, 'left')

        tela.blit(opcao_textos[2], (x_centro + 200 - opcao_textos[2].get_width() // 2, y_centro - 50))
        desenhar_seta(x_centro + 200, y_centro - 100, 'right')

        tela.blit(opcao_textos[3], (x_centro - opcao_textos[3].get_width() // 2, y_centro + 50))
        desenhar_seta(x_centro, y_centro + 100, 'down')  

        # Exibir rodada e tempo
        rodada_texto = fonte.render(f"Rodada: {rodada} / 10", True, AZUL)
        restantes_texto = fonte.render(f"Faltam: {rodada_restante} rodadas", True, AZUL)
        pontos_texto = fonte_pontos.render(f"PONTOS: {pontos}", True, AZUL)
        tela.blit(pontos_texto, (10, 10))
        tela.blit(rodada_texto, (10, ALTURA_TELA - 100))
        tela.blit(restantes_texto, (10, ALTURA_TELA - 60))

        # Timer
        t = tempo_maximo
        tempo_inicial = time.time()
        selecionado = -1
        escolha_confirmada = False
        tecla_pressionada = None
        tempo_pressionamento = 0

        while not escolha_confirmada:
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    return
                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_UP:
                        tecla_pressionada = "up"
                        tempo_pressionamento = pygame.time.get_ticks()
                    elif evento.key == pygame.K_RIGHT:
                        tecla_pressionada = "right"
                        tempo_pressionamento = pygame.time.get_ticks()
                    elif evento.key == pygame.K_DOWN:
                        tecla_pressionamento = pygame.time.get_ticks()
                        tecla_pressionada = "down"
                    elif evento.key == pygame.K_LEFT:
                        tecla_pressionamento = pygame.time.get_ticks()
                        tecla_pressionada = "left"

                if evento.type == pygame.KEYUP:
                    if evento.key in [pygame.K_UP, pygame.K_RIGHT, pygame.K_DOWN, pygame.K_LEFT]:
                        tecla_pressionada = None  # Se soltou a tecla, limpar

            # Verificar se a tecla foi pressionada por 0.2 segundos
            if tecla_pressionada:
                if pygame.time.get_ticks() - tempo_pressionamento >= 100:  # 200ms = 0.2 segundos
                    if tecla_pressionada == "up":
                        selecionado = 0
                    elif tecla_pressionada == "right":
                        selecionado = 2
                    elif tecla_pressionada == "down":
                        selecionado = 3
                    elif tecla_pressionada == "left":
                        selecionado = 1
                    tecla_pressionada = None  # Após registrar, limpar

            # Atualizar o tempo
            t = tempo_maximo - int(time.time() - tempo_inicial)
            if t <= 0:
                escolha_confirmada = True
                pontos -= multiplicador  # Penaliza se o tempo acaba
            else:
                desenhar_timer(t, tempo_maximo)

            # Verifica se o jogador escolheu a opção correta
            if selecionado != -1 and t > 0:
                # Calculando o bônus de tempo
                tempo_percentual = (tempo_maximo - t) / tempo_maximo
                if tempo_percentual <= 0.2:
                    bonus = 4
                elif tempo_percentual <= 0.4:
                    bonus = 3
                elif tempo_percentual <= 0.6:
                    bonus = 2
                elif tempo_percentual <= 0.8:
                    bonus = 1
                else:
                    bonus = 0

                if opcoes[selecionado] == palavra_correta:
                    pontos += multiplicador * bonus  # Aplicando bônus de tempo
                    som_acerto.play()  # Som de acerto
                    ultima_mudanca = multiplicador * bonus
                else:
                    pontos -= multiplicador
                    som_erro.play()  # Som de erro
                    ultima_mudanca = -multiplicador
                escolha_confirmada = True
                tempo_mudanca = time.time()

           # Mostra mudança na pontuação
            if time.time() - tempo_mudanca < 1 :
                if ultima_mudanca>0:
                    sinal="+"
                    cor_mud = VERDE
                else:
                    sinal=""
                    cor_mud = VERMELHO
                mudanca = f"{sinal}{ultima_mudanca}"
                mudanca_txt = fonte_pontos.render(mudanca, True, cor_mud)
                pos_pontos=pontos_texto.get_width()+10
                tmnh_txt=mudanca_txt.get_width()
                tela.blit(mudanca_txt,((pos_pontos-tmnh_txt),50))
                
            pygame.display.flip()
            pygame.time.delay(100)

        pygame.display.flip()
        pygame.time.delay(1000)  # Pausa de 1 segundo
        clock.tick(30)

    resultado = tela_final(pontos, multiplicador)
    if resultado == "reiniciar":
        jogo(tempo_maximo, multiplicador)
    elif resultado == "proximo_nivel":
        multiplicador += 1
        jogo(tempo_maximo, multiplicador)
    elif resultado == "menu_niveis":
        menu_dificuldade()


if __name__ == "__main__":
    menu_inicial()

    

# Finalizar o Pygame
pygame.quit()
