#animais no comeco, bugggggg

import pygame
import random
import time

# Inicializar o Pygame
pygame.init()

# Definindo as cores
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
AZUL = (0, 0, 255)
VERDE = (0, 255, 0)
VERMELHO = (255, 0, 0)
AMARELO = (255, 255, 0)

# Configurações da tela
LARGURA_TELA = 1100
ALTURA_TELA = 700  # Aumentada a altura para dar mais espaço para as opções
tela = pygame.display.set_mode((LARGURA_TELA, ALTURA_TELA))
pygame.display.set_caption("Associa Imagem")
fundo = pygame.image.load("grassland.png")

# Fontes
fonte = pygame.font.SysFont("Arial", 30)
fonte_pontos = pygame.font.SysFont("Arial", 40)

# Carregar música e sons
pygame.mixer.music.load("musica_fundo.mp3")  # Substitua pelo caminho da sua música
pygame.mixer.music.set_volume(0.2)  # Ajuste o volume da música (de 0.0 a 1.0)
pygame.mixer.music.play(-1)  # -1 para tocar em loop

# Sons de feedback
som_acerto = pygame.mixer.Sound("acerto.wav")  # Substitua pelo caminho do seu som de acerto
som_erro = pygame.mixer.Sound("erro.wav")  # Substitua pelo caminho do seu som de erro

# Carregar imagens dos estados do personagem
personagem_feliz = pygame.image.load("personagem1.png") 
personagem_triste = pygame.image.load("personagem2.png")
personagem_normal = pygame.image.load("personagem3.png")
personagem_normal = pygame.transform.scale(personagem_normal, (160, 160))

# Lista de imagens e suas palavras associadas
imagens = [
    {"imagem": "imagem1.png", "palavra": "Cachorro"},
    {"imagem": "imagem2.png", "palavra": "Gato"},
    {"imagem": "imagem3.png", "palavra": "Leão"},
    {"imagem": "imagem4.png", "palavra": "Elefante"},
    {"imagem": "imagem5.png", "palavra": "Peixe"},
    {"imagem": "imagem6.png", "palavra": "Cavalo"},
    {"imagem": "imagem7.png", "palavra": "Vaca"},
    {"imagem": "imagem8.png", "palavra": "Galinha"},
    {"imagem": "imagem9.png", "palavra": "Rino"},
    {"imagem": "imagem10.png", "palavra": "Porco"},
    # Adicione mais imagens e palavras conforme necessário
]

novo_tamanho = (100, 100)  # Tamanho para redimensionar as imagens

for item in imagens:
    item["imagem"] = pygame.image.load(item["imagem"])  # Carregar a imagem
    item["imagem"] = pygame.transform.scale(item["imagem"], novo_tamanho)  # Redimensionar a imagem

# Função para desenhar os animais movendo pela tela
def desenhar_animais(animais, velocidade):
    for animal in animais:
        # Movendo os animais com uma velocidade mais controlada
        x = random.randint(0, LARGURA_TELA - animal["imagem"].get_width())
        y = random.randint(0, ALTURA_TELA - animal["imagem"].get_height())

        # Atualizando a posição com base na velocidade
        x += velocidade
        y += velocidade

        # Garantir que o animal não ultrapasse os limites da tela
        if x < 0:
            x = 0
        elif x > LARGURA_TELA - animal["imagem"].get_width():
            x = LARGURA_TELA - animal["imagem"].get_width()

        if y < 0:
            y = 0
        elif y > ALTURA_TELA - animal["imagem"].get_height():
            y = ALTURA_TELA - animal["imagem"].get_height()

        # Desenha a imagem do animal na tela
        tela.blit(animal["imagem"], (x, y))


def desenhar_personagem(estado="normal", mensagem=""):
    # Obter dimensões da tela
    largura_tela = tela.get_width()
    altura_tela = tela.get_height()

    # Tamanho máximo permitido para o personagem (20% da largura e 30% da altura da tela)
    largura_max = largura_tela // 5
    altura_max = altura_tela // 3

    # Selecionar a imagem com base no estado
    if estado == "feliz":
        imagem = personagem_feliz
    elif estado == "triste":
        imagem = personagem_triste
    elif estado == "normal":
        imagem = personagem_normal
    else:
        imagem = personagem_normal

    # Redimensionar a imagem para caber nos limites definidos
    largura_imagem = imagem.get_width()
    altura_imagem = imagem.get_height()

    escala_largura = largura_max / largura_imagem
    escala_altura = altura_max / altura_imagem
    escala = min(escala_largura, escala_altura)  # Escolhe a menor escala para manter proporção

    nova_largura = int(largura_imagem * escala)
    nova_altura = int(altura_imagem * escala)
    imagem_redimensionada = pygame.transform.scale(imagem, (nova_largura, nova_altura))

    # Calcular posição no canto inferior direito
    posicao_x = largura_tela - nova_largura - 10  # 10px de margem da borda direita
    posicao_y = altura_tela - nova_altura - 10  # 10px de margem da borda inferior

    if mensagem:
        texto = fonte.render(mensagem, True, PRETO)
        texto_x = posicao_x + nova_largura // 2 - texto.get_width() // 2
        texto_y = posicao_y - texto.get_height() - 10
        tela.blit(texto, (texto_x, texto_y))

    # Desenhar a imagem na tela
    tela.blit(imagem_redimensionada, (posicao_x, posicao_y))

estado_atual = "normal"

# Função para a tela inicial
def tela_inicial():
    global running
    animando = True
    clock = pygame.time.Clock()  # Criar um objeto Clock para controlar o tempo
    velocidade = 10  # A velocidade de movimento dos animais (ajuste aqui para mais lento ou mais rápido)

    while animando:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                animando = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Se pressionar Enter, sai da tela inicial
                    animando = False

        # Preencher a tela com a cor de fundo
        tela.fill(AZUL)

        personagem_x = 150
        personagem_y = ALTURA_TELA // 2 - 50
        tela.blit(personagem_normal, (personagem_x, personagem_y))  # Desenha a imagem do personagem

        # Texto do personagem
        fonte_personagem = pygame.font.SysFont(None, 30)
        texto_personagem = fonte_personagem.render("Ajuda a capturar os animais fugindo!", True, PRETO)
        tela.blit(texto_personagem, (personagem_x + 70, personagem_y - 20))


        # Desenhar os animais se movendo com a velocidade controlada
        desenhar_animais(imagens, velocidade)

        # Instrução para pressionar Enter
        fonte_instrucoes = pygame.font.SysFont(None, 30)
        texto_enter = fonte_instrucoes.render("Pressione Enter para começar", True, PRETO)
        tela.blit(texto_enter, (LARGURA_TELA // 2 - 120, ALTURA_TELA // 2 + 100))

        # Atualizar a tela
        pygame.display.flip()

        # Controlar a taxa de atualização e a velocidade dos animais (FPS)
        clock.tick(1)  # Controla a taxa de quadros por segundo (FPS)



def borrar_tela():
    # Preencher a tela com uma cor semitransparente para dar o efeito de borrão
    tela.fill(AMARELO)  # Pode mudar para outra cor, se preferir
    pygame.display.update()
    time.sleep(0.2)

def animar_alegria():
    # Exemplo simples de animação de pulo (movendo o personagem para cima e para baixo)
    for i in range(10):
        tela.fill(BRANCO)  # Limpar tela
        desenhar_personagem(50, ALTURA_TELA - 150 - i * 5, "feliz")
        pygame.display.update()
        time.sleep(0.05)
    for i in range(10):
        tela.fill(BRANCO)  # Limpar tela
        desenhar_personagem(50, ALTURA_TELA - 150 + i * 5, "feliz")
        pygame.display.update()
        time.sleep(0.05)



# Função para desenhar o timer
def desenhar_timer(t, tempo_maximo):
    pygame.draw.rect(tela, PRETO, (LARGURA_TELA - 150, 20, 130, 30))
    pygame.draw.rect(tela, VERDE, (LARGURA_TELA - 150, 20, (130 * t) / tempo_maximo, 30))
    timer_text = fonte.render(f"Tempo: {t}", True, BRANCO)
    tela.blit(timer_text, (LARGURA_TELA - 140, 20))

# Função para desenhar setas de direção
def desenhar_seta(x, y, direcao):
    if direcao == 'up':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 10, y + 20), (x + 10, y + 20)])
    elif direcao == 'down':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 10, y - 20), (x + 10, y - 20)])
    elif direcao == 'left':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x + 20, y - 10), (x + 20, y + 10)])
    elif direcao == 'right':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 20, y - 10), (x - 20, y + 10)])

# Função para desenhar a caixa para a imagem
def desenhar_caixa_imagem():
    pygame.draw.rect(tela, AZUL, (LARGURA_TELA // 2 - 160, 10, 320, 320), 5)  # Caixa encostada no topo

def tela_final(pontos):
    tela.fill(BRANCO)
    resultado_texto = fonte_pontos.render(f"Fim do Jogo! Pontuação Final: {pontos}", True, VERDE)
    tela.blit(resultado_texto, (LARGURA_TELA // 2 - resultado_texto.get_width() // 2, ALTURA_TELA // 2 - 50))

    # Opções de continuar ou sair
    continuar_texto = fonte.render("Pressione R para jogar novamente", True, AZUL)
    sair_texto = fonte.render("Pressione ESC para sair", True, AZUL)
    
    tela.blit(continuar_texto, (LARGURA_TELA // 2 - continuar_texto.get_width() // 2, ALTURA_TELA // 2 + 50))
    tela.blit(sair_texto, (LARGURA_TELA // 2 - sair_texto.get_width() // 2, ALTURA_TELA // 2 + 100))
    
    pygame.display.flip()

    esperando = True
    while esperando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_r:  # Jogar novamente
                    return True
                elif evento.key == pygame.K_ESCAPE:  # Sair
                    pygame.quit()
                    exit()

    return False  # Caso o jogo termine sem pressionar R

# Função para desenhar o menu inicial
def menu_inicial():
    tela.fill(BRANCO)
    
    titulo = fonte_pontos.render("Jogo de Associação Imagem e Palavra", True, AZUL)
    tela.blit(titulo, (LARGURA_TELA // 2 - titulo.get_width() // 2, ALTURA_TELA // 4))
    
    comecar_texto = fonte.render("Pressione ENTER para começar", True, AZUL)
    tela.blit(comecar_texto, (LARGURA_TELA // 2 - comecar_texto.get_width() // 2, ALTURA_TELA // 2))
    
    sair_texto = fonte.render("Pressione ESC para sair", True, AZUL)
    tela.blit(sair_texto, (LARGURA_TELA // 2 - sair_texto.get_width() // 2, ALTURA_TELA // 2 + 50))
    
    pygame.display.flip()

    # Aguardar a interação do usuário
    esperando = True
    while esperando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_RETURN:  # Iniciar o jogo
                    return True
                elif evento.key == pygame.K_ESCAPE:  # Sair do jogo
                    pygame.quit()
                    exit()

# Função para desenhar o menu de seleção de dificuldade
def menu_dificuldade():
    tela.fill(BRANCO)

    titulo = fonte_pontos.render("Escolha a Dificuldade", True, AZUL)
    tela.blit(titulo, (LARGURA_TELA // 2 - titulo.get_width() // 2, ALTURA_TELA // 4))

    facil_texto = fonte.render("1-Fácil (30 segundos)", True, AZUL)
    tela.blit(facil_texto, (LARGURA_TELA // 2 - facil_texto.get_width() // 2, ALTURA_TELA // 2 - 50))

    medio_texto = fonte.render("2-Médio (15 segundos)", True, AZUL)
    tela.blit(medio_texto, (LARGURA_TELA // 2 - medio_texto.get_width() // 2, ALTURA_TELA // 2))

    dificil_texto = fonte.render("3-Difícil (5 segundos)", True, AZUL)
    tela.blit(dificil_texto, (LARGURA_TELA // 2 - dificil_texto.get_width() // 2, ALTURA_TELA // 2 + 50))

    pygame.display.flip()

    # Aguardar a interação do usuário para selecionar a dificuldade
    esperando = True
    while esperando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_1:
                    return 30, 1  # Fácil
                elif evento.key == pygame.K_2:
                    return 15, 2  # Médio
                elif evento.key == pygame.K_3:
                    return 5, 3  # Difícil

# Atualização na função para desenhar as opções
def jogo(tempo_maximo, multiplicador):
    pontos = 0
    rodada = 0
    imagens_usadas = []
    opcoes = []

    while rodada < 10:
        rodada += 1
        rodada_restante = 10 - rodada
        tela.fill(BRANCO)

        # Selecionar uma imagem aleatória
        imagem_atual = random.choice([img for img in imagens if img not in imagens_usadas])
        imagens_usadas.append(imagem_atual)

        palavra_correta = imagem_atual["palavra"]
        opcoes = random.sample([img["palavra"] for img in imagens if img != imagem_atual], 3)
        opcoes.append(palavra_correta)
        random.shuffle(opcoes)

        desenhar_caixa_imagem()

        # Exibir a imagem
        img = pygame.image.load(imagem_atual["imagem"])
        img = pygame.transform.scale(img, (300, 300))  # Redimensiona
        tela.blit(img, (LARGURA_TELA // 2 - 150, 10))

        x_centro = LARGURA_TELA // 2
        y_centro = ALTURA_TELA - 150  # Movendo as opções para baixo

        opcao_textos = []
        for i, opcao in enumerate(opcoes):
            texto = fonte.render(opcao, True, AZUL)
            opcao_textos.append(texto)

        # Desenhar as opções
        tela.blit(opcao_textos[0], (x_centro - opcao_textos[0].get_width() // 2, y_centro - 200))
        desenhar_seta(x_centro, y_centro - 150, 'up')

        tela.blit(opcao_textos[1], (x_centro - 200 - opcao_textos[1].get_width() // 2, y_centro - 50))
        desenhar_seta(x_centro - 200, y_centro - 100, 'left')

        tela.blit(opcao_textos[2], (x_centro + 200 - opcao_textos[2].get_width() // 2, y_centro - 50))
        desenhar_seta(x_centro + 200, y_centro - 100, 'right')

        tela.blit(opcao_textos[3], (x_centro - opcao_textos[3].get_width() // 2, y_centro + 50))
        desenhar_seta(x_centro, y_centro + 100, 'down')  

        # Exibir rodada e tempo
        rodada_texto = fonte.render(f"Rodada: {rodada} / 10", True, AZUL)
        restantes_texto = fonte.render(f"Faltam: {rodada_restante} rodadas", True, AZUL)
        tela.blit(rodada_texto, (10, ALTURA_TELA - 100))
        tela.blit(restantes_texto, (10, ALTURA_TELA - 60))

        # Timer
        t = tempo_maximo
        tempo_inicial = time.time()
        selecionado = -1
        escolha_confirmada = False
        tecla_pressionada = None
        tempo_pressionamento = 0

        while not escolha_confirmada:
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    return
                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_UP:
                        tecla_pressionada = "up"
                        tempo_pressionamento = pygame.time.get_ticks()
                    elif evento.key == pygame.K_RIGHT:
                        tecla_pressionada = "right"
                        tempo_pressionamento = pygame.time.get_ticks()
                    elif evento.key == pygame.K_DOWN:
                        tecla_pressionamento = pygame.time.get_ticks()
                        tecla_pressionada = "down"
                    elif evento.key == pygame.K_LEFT:
                        tecla_pressionamento = pygame.time.get_ticks()
                        tecla_pressionada = "left"


                if evento.type == pygame.KEYUP:
                    if evento.key in [pygame.K_UP, pygame.K_RIGHT, pygame.K_DOWN, pygame.K_LEFT]:
                        tecla_pressionada = None  # Se soltou a tecla, limpar

            # Verificar se a tecla foi pressionada por 0.2 segundos
            if tecla_pressionada:
                if pygame.time.get_ticks() - tempo_pressionamento >= 10:  # 200ms = 0.2 segundos
                    if tecla_pressionada == "up":
                        selecionado = 0
                    elif tecla_pressionada == "right":
                        selecionado = 2
                    elif tecla_pressionada == "down":
                        selecionado = 3
                    elif tecla_pressionada == "left":
                        selecionado = 1
                    tecla_pressionada = None  # Após registrar, limpar


            # Atualizar o tempo
            t = tempo_maximo - int(time.time() - tempo_inicial)
            if t <= 0:
                escolha_confirmada = True
                pontos -= multiplicador  # Penaliza no tempo
            else:
                desenhar_timer(t, tempo_maximo)

            # Verifica se o jogador escolheu a opção correta
            if selecionado != -1 and t > 0:
                # Calculando o bônus de tempo
                tempo_percentual = (tempo_maximo - t) / tempo_maximo
                if tempo_percentual <= 0.2:
                    bonus = 4
                elif tempo_percentual <= 0.4:
                    bonus = 3
                elif tempo_percentual <= 0.6:
                    bonus = 2
                elif tempo_percentual <= 0.8:
                    bonus = 1
                else:
                    bonus = 0

                estados = "normal"
                if opcoes[selecionado] == palavra_correta:
                    pontos += multiplicador * bonus  # Aplicando bônus de tempo
                    som_acerto.play()  # Som de acerto
                    estados = "feliz"
                    mensagem = "Você acertou ^v^"
                else:
                    pontos -= multiplicador
                    som_erro.play()  # Som de erro
                    estados = "triste"
                    mensagem = "Você errou :("
                escolha_confirmada = True
                desenhar_personagem(estados, mensagem)
            
            pygame.display.flip()
            pygame.time.delay(100)

        pontos_texto = fonte_pontos.render(f"Pontos: {pontos}", True, VERDE)
        tela.blit(pontos_texto, (10, 10))

        pygame.display.flip()
        pygame.time.delay(1000)  # Pausa de 1 segundo

    if tela_final(pontos):  # Se pressionar R, reiniciar o jogo
        jogo(tempo_maximo, multiplicador)


tela_inicial()

# Mostrar o menu inicial
if menu_inicial():
    tempo_maximo, multiplicador = menu_dificuldade()
    jogo(tempo_maximo, multiplicador)
    

# Finalizar o Pygame
pygame.quit()
