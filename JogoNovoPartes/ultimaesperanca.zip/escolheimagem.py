import pygame
import random
import time

# Inicializar o Pygame
pygame.init()

# Definindo as cores
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
AZUL = (0, 0, 255)
VERDE = (0, 255, 0)
VERMELHO = (255, 0, 0)

# Configurações da tela
LARGURA_TELA = 800
ALTURA_TELA = 700  # Aumentada a altura para dar mais espaço para as opções
tela = pygame.display.set_mode((LARGURA_TELA, ALTURA_TELA))
pygame.display.set_caption("Associa Imagem")

# Fontes
fonte = pygame.font.SysFont("Arial", 30)
fonte_pontos = pygame.font.SysFont("Arial", 40)

# Carregar música e sons
pygame.mixer.music.load("musica_fundo.mp3")  # Substitua pelo caminho da sua música
pygame.mixer.music.set_volume(0.2)  # Ajuste o volume da música (de 0.0 a 1.0)
pygame.mixer.music.play(-1)  # -1 para tocar em loop

# Sons de feedback
som_acerto = pygame.mixer.Sound("acerto.wav")  # Substitua pelo caminho do seu som de acerto
som_erro = pygame.mixer.Sound("erro.wav")  # Substitua pelo caminho do seu som de erro

# Lista de imagens e suas palavras associadas
imagens = [
    {"imagem": "imagem1.png", "palavra": "Cachorro"},
    {"imagem": "imagem2.png", "palavra": "Gato"},
    {"imagem": "imagem3.png", "palavra": "Leão"},
    {"imagem": "imagem4.png", "palavra": "Elefante"},
    {"imagem": "imagem5.png", "palavra": "Peixe"},
    {"imagem": "imagem6.png", "palavra": "Cavalo"},
    {"imagem": "imagem7.png", "palavra": "Vaca"},
    {"imagem": "imagem8.png", "palavra": "Galinha"},
    {"imagem": "imagem9.png", "palavra": "Rino"},
    {"imagem": "imagem10.png", "palavra": "Porco"},
    # Adicione mais imagens e palavras conforme necessário
]

# Função para desenhar o timer
def desenhar_timer(t, tempo_maximo):
    pygame.draw.rect(tela, PRETO, (LARGURA_TELA - 150, 20, 130, 30))
    pygame.draw.rect(tela, VERDE, (LARGURA_TELA - 150, 20, (130 * t) / tempo_maximo, 30))
    timer_text = fonte.render(f"Tempo: {t}", True, BRANCO)
    tela.blit(timer_text, (LARGURA_TELA - 140, 20))

# Função para desenhar setas de direção
def desenhar_seta(x, y, direcao):
    if direcao == 'up':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 10, y + 20), (x + 10, y + 20)])
    elif direcao == 'down':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 10, y - 20), (x + 10, y - 20)])
    elif direcao == 'left':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x + 20, y - 10), (x + 20, y + 10)])
    elif direcao == 'right':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 20, y - 10), (x - 20, y + 10)])

# Função para desenhar a caixa para a imagem
def desenhar_caixa_imagem():
    pygame.draw.rect(tela, AZUL, (LARGURA_TELA // 2 - 160, 10, 320, 320), 5)  # Caixa encostada no topo

def tela_final(pontos):
    tela.fill(BRANCO)
    resultado_texto = fonte_pontos.render(f"Fim do Jogo! Pontuação Final: {pontos}", True, VERDE)
    tela.blit(resultado_texto, (LARGURA_TELA // 2 - resultado_texto.get_width() // 2, ALTURA_TELA // 2 - 50))

    # Opções de continuar ou sair
    continuar_texto = fonte.render("Pressione R para jogar novamente", True, AZUL)
    sair_texto = fonte.render("Pressione ESC para sair", True, AZUL)
    
    tela.blit(continuar_texto, (LARGURA_TELA // 2 - continuar_texto.get_width() // 2, ALTURA_TELA // 2 + 50))
    tela.blit(sair_texto, (LARGURA_TELA // 2 - sair_texto.get_width() // 2, ALTURA_TELA // 2 + 100))
    
    pygame.display.flip()

    esperando = True
    while esperando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_r:  # Jogar novamente
                    return True
                elif evento.key == pygame.K_ESCAPE:  # Sair
                    pygame.quit()
                    exit()

    return False  # Caso o jogo termine sem pressionar R

# Função para desenhar o menu inicial
def menu_inicial():
    tela.fill(BRANCO)
    
    titulo = fonte_pontos.render("Jogo de Associação Imagem e Palavra", True, AZUL)
    tela.blit(titulo, (LARGURA_TELA // 2 - titulo.get_width() // 2, ALTURA_TELA // 4))
    
    comecar_texto = fonte.render("Pressione ENTER para começar", True, AZUL)
    tela.blit(comecar_texto, (LARGURA_TELA // 2 - comecar_texto.get_width() // 2, ALTURA_TELA // 2))
    
    sair_texto = fonte.render("Pressione ESC para sair", True, AZUL)
    tela.blit(sair_texto, (LARGURA_TELA // 2 - sair_texto.get_width() // 2, ALTURA_TELA // 2 + 50))
    
    pygame.display.flip()

    # Aguardar a interação do usuário
    esperando = True
    while esperando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_RETURN:  # Iniciar o jogo
                    return True
                elif evento.key == pygame.K_ESCAPE:  # Sair do jogo
                    pygame.quit()
                    exit()

# Função para desenhar o menu de seleção de dificuldade
def menu_dificuldade():
    tela.fill(BRANCO)

    titulo = fonte_pontos.render("Escolha a Dificuldade", True, AZUL)
    tela.blit(titulo, (LARGURA_TELA // 2 - titulo.get_width() // 2, ALTURA_TELA // 4))

    facil_texto = fonte.render("1-Fácil (30 segundos)", True, AZUL)
    tela.blit(facil_texto, (LARGURA_TELA // 2 - facil_texto.get_width() // 2, ALTURA_TELA // 2 - 50))

    medio_texto = fonte.render("2-Médio (15 segundos)", True, AZUL)
    tela.blit(medio_texto, (LARGURA_TELA // 2 - medio_texto.get_width() // 2, ALTURA_TELA // 2))

    dificil_texto = fonte.render("3-Difícil (5 segundos)", True, AZUL)
    tela.blit(dificil_texto, (LARGURA_TELA // 2 - dificil_texto.get_width() // 2, ALTURA_TELA // 2 + 50))

    pygame.display.flip()

    # Aguardar a interação do usuário para selecionar a dificuldade
    esperando = True
    while esperando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_1:
                    return 30, 1  # Fácil
                elif evento.key == pygame.K_2:
                    return 15, 2  # Médio
                elif evento.key == pygame.K_3:
                    return 5, 3  # Difícil

# Atualização na função para desenhar as opções
def jogo(tempo_maximo, multiplicador):
    pontos = 0
    rodada = 0
    imagens_usadas = []
    opcoes = []

    while rodada < 10:
        rodada += 1
        rodada_restante = 10 - rodada
        tela.fill(BRANCO)

        # Selecionar uma imagem aleatória
        imagem_atual = random.choice([img for img in imagens if img not in imagens_usadas])
        imagens_usadas.append(imagem_atual)

        palavra_correta = imagem_atual["palavra"]
        opcoes = random.sample([img["palavra"] for img in imagens if img != imagem_atual], 3)
        opcoes.append(palavra_correta)
        random.shuffle(opcoes)

        desenhar_caixa_imagem()

        # Exibir a imagem
        img = pygame.image.load(imagem_atual["imagem"])
        img = pygame.transform.scale(img, (300, 300))  # Redimensiona
        tela.blit(img, (LARGURA_TELA // 2 - 150, 10))

        x_centro = LARGURA_TELA // 2
        y_centro = ALTURA_TELA - 150  # Movendo as opções para baixo

        opcao_textos = []
        for i, opcao in enumerate(opcoes):
            texto = fonte.render(opcao, True, AZUL)
            opcao_textos.append(texto)

        # Desenhar as opções
        tela.blit(opcao_textos[0], (x_centro - opcao_textos[0].get_width() // 2, y_centro - 200))
        desenhar_seta(x_centro, y_centro - 150, 'up')

        tela.blit(opcao_textos[1], (x_centro - 200 - opcao_textos[1].get_width() // 2, y_centro - 50))
        desenhar_seta(x_centro - 200, y_centro - 100, 'left')

        tela.blit(opcao_textos[2], (x_centro + 200 - opcao_textos[2].get_width() // 2, y_centro - 50))
        desenhar_seta(x_centro + 200, y_centro - 100, 'right')

        tela.blit(opcao_textos[3], (x_centro - opcao_textos[3].get_width() // 2, y_centro + 50))
        desenhar_seta(x_centro, y_centro + 100, 'down')  

        # Exibir rodada e tempo
        rodada_texto = fonte.render(f"Rodada: {rodada} / 10", True, AZUL)
        restantes_texto = fonte.render(f"Faltam: {rodada_restante} rodadas", True, AZUL)
        tela.blit(rodada_texto, (10, ALTURA_TELA - 100))
        tela.blit(restantes_texto, (10, ALTURA_TELA - 60))

        # Timer
        t = tempo_maximo
        tempo_inicial = time.time()
        selecionado = -1
        escolha_confirmada = False
        tecla_pressionada = None
        tempo_pressionamento = 0

        while not escolha_confirmada:
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    return
                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_UP:
                        tecla_pressionada = "up"
                        tempo_pressionamento = pygame.time.get_ticks()
                    elif evento.key == pygame.K_RIGHT:
                        tecla_pressionada = "right"
                        tempo_pressionamento = pygame.time.get_ticks()
                    elif evento.key == pygame.K_DOWN:
                        tecla_pressionamento = pygame.time.get_ticks()
                        tecla_pressionada = "down"
                    elif evento.key == pygame.K_LEFT:
                        tecla_pressionamento = pygame.time.get_ticks()
                        tecla_pressionada = "left"

                if evento.type == pygame.KEYUP:
                    if evento.key in [pygame.K_UP, pygame.K_RIGHT, pygame.K_DOWN, pygame.K_LEFT]:
                        tecla_pressionada = None  # Se soltou a tecla, limpar

            # Verificar se a tecla foi pressionada por 0.2 segundos
            if tecla_pressionada:
                if pygame.time.get_ticks() - tempo_pressionamento >= 10:  # 200ms = 0.2 segundos
                    if tecla_pressionada == "up":
                        selecionado = 0
                    elif tecla_pressionada == "right":
                        selecionado = 2
                    elif tecla_pressionada == "down":
                        selecionado = 3
                    elif tecla_pressionada == "left":
                        selecionado = 1
                    tecla_pressionada = None  # Após registrar, limpar

            # Atualizar o tempo
            t = tempo_maximo - int(time.time() - tempo_inicial)
            if t <= 0:
                escolha_confirmada = True
                pontos -= multiplicador  # Penaliza no tempo
            else:
                desenhar_timer(t, tempo_maximo)

            # Verifica se o jogador escolheu a opção correta
            if selecionado != -1 and t > 0:
                # Calculando o bônus de tempo
                tempo_percentual = (tempo_maximo - t) / tempo_maximo
                if tempo_percentual <= 0.2:
                    bonus = 4
                elif tempo_percentual <= 0.4:
                    bonus = 3
                elif tempo_percentual <= 0.6:
                    bonus = 2
                elif tempo_percentual <= 0.8:
                    bonus = 1
                else:
                    bonus = 0

                if opcoes[selecionado] == palavra_correta:
                    pontos += multiplicador * bonus  # Aplicando bônus de tempo
                    som_acerto.play()  # Som de acerto
                else:
                    pontos -= multiplicador
                    som_erro.play()  # Som de erro
                escolha_confirmada = True

            pygame.display.flip()
            pygame.time.delay(100)

        pontos_texto = fonte_pontos.render(f"Pontos: {pontos}", True, VERDE)
        tela.blit(pontos_texto, (10, 10))

        pygame.display.flip()
        pygame.time.delay(1000)  # Pausa de 1 segundo

    if tela_final(pontos):  # Se pressionar R, reiniciar o jogo
        jogo(tempo_maximo, multiplicador)

# Mostrar o menu inicial
if menu_inicial():
    tempo_maximo, multiplicador = menu_dificuldade()
    jogo(tempo_maximo, multiplicador)
    

# Finalizar o Pygame
pygame.quit()
