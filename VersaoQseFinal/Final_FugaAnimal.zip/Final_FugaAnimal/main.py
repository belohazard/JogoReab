import pygame
import random
import time

pygame.init()

PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
BEGE = (245, 245, 220)
CINZA = (46, 46, 46)
AZUL = (0, 0, 255)
VERDE = (0, 128, 0)
VERMELHO = (255, 0, 0)
VERMELHO_TIMER = (208, 0, 0)
AMARELO = (255, 255, 0)

LARGURA_TELA = 1100
ALTURA_TELA = 700
tela = pygame.display.set_mode((LARGURA_TELA, ALTURA_TELA))
surface = pygame.Surface((LARGURA_TELA, ALTURA_TELA), pygame.SRCALPHA)
pygame.display.set_caption("Fuga Animal")

clock = pygame.time.Clock()
pausado = False

fonte_pontos = pygame.font.Font("Montserrat-Regular.ttf", 35)
fonte = pygame.font.Font("Montserrat-Regular.ttf", 25)

pygame.mixer.music.load("musica_fundo.mp3")
pygame.mixer.music.set_volume(0.2)
pygame.mixer.music.play(-1)

som_acerto = pygame.mixer.Sound("acerto.wav")
som_erro = pygame.mixer.Sound("erro.wav")

personagem_feliz = pygame.image.load("personagem1.png")
personagem_triste = pygame.image.load("personagem2.png")
personagem_normal = pygame.image.load("personagem3.png")
personagem_normal = pygame.transform.scale(personagem_normal, (160, 350))

imagens = [
    {"imagem": "imagem1.png", "palavra": "Macaco"},
    {"imagem": "imagem2.png", "palavra": "Rinoceronte"},
    {"imagem": "imagem3.png", "palavra": "Leão"},
    {"imagem": "imagem4.png", "palavra": "Elefante"},
    {"imagem": "imagem5.png", "palavra": "Onça"},
    {"imagem": "imagem6.png", "palavra": "Cavalo"},
    {"imagem": "imagem7.png", "palavra": "Avestruz"},
    {"imagem": "imagem8.png", "palavra": "Zebra"},
    {"imagem": "imagem9.png", "palavra": "Hipopotamo"},
    {"imagem": "imagem10.png", "palavra": "Porco"},
    {"imagem": "imagem11.png", "palavra": "Girafa"},
    {"imagem": "imagem12.png", "palavra": "Canguru"},
    {"imagem": "imagem13.png", "palavra": "Urso"},
    {"imagem": "imagem14.png", "palavra": "Koala"},
    {"imagem": "imagem15.png", "palavra": "Capivara"},
    {"imagem": "imagem16.png", "palavra": "Pavão"},
    {"imagem": "imagem17.png", "palavra": "Raposa"},
    {"imagem": "imagem18.png", "palavra": "Panda"},
    {"imagem": "imagem19.png", "palavra": "Pinguim"},
]

def desenhar_personagem(estado="normal", mensagem=""):
    largura_tela = tela.get_width()
    altura_tela = tela.get_height()
    largura_max = largura_tela // 4
    altura_max = altura_tela // 2

    if estado == "feliz":
        imagem = personagem_feliz
    elif estado == "triste":
        imagem = personagem_triste
    elif estado == "normal":
        imagem = personagem_normal
    else:
        imagem = personagem_normal

    largura_imagem = imagem.get_width()
    altura_imagem = imagem.get_height()

    escala_largura = largura_max / largura_imagem
    escala_altura = altura_max / altura_imagem
    escala = min(escala_largura, escala_altura)

    nova_largura = int(largura_imagem * escala)
    nova_altura = int(altura_imagem * escala)
    imagem_redimensionada = pygame.transform.scale(imagem, (nova_largura, nova_altura))

    posicao_x = largura_tela - nova_largura - 70
    posicao_y = altura_tela - nova_altura - 30

    if mensagem:
        texto = fonte.render(mensagem, True, PRETO)
        texto_x = posicao_x + nova_largura // 2 - texto.get_width() // 2
        texto_y = posicao_y - texto.get_height() - 10
        tela.blit(texto, (texto_x, texto_y))

    tela.blit(imagem_redimensionada, (posicao_x, posicao_y))

estado_atual = "normal"

def tela_inicial():
    animando = True
    clock = pygame.time.Clock()

    while animando:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                animando = False
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    animando = False

        tela.fill(BEGE)
        personagem_x = 70
        personagem_y = ALTURA_TELA // 2 - 150
        tela.blit(personagem_normal, (personagem_x, personagem_y))

        fonte_personagem = pygame.font.SysFont(None, 50)
        texto_personagem = fonte_personagem.render("Ajuda a capturar os animais fugindo!", True, PRETO)
        tela.blit(texto_personagem, (LARGURA_TELA // 2 - 200, ALTURA_TELA // 2 - 200))

        fonte_instrucoes = pygame.font.SysFont(None, 40)
        texto_enter1 = fonte_instrucoes.render("Pressione Espaço para me ajudar", True, VERMELHO)
        tela.blit(texto_enter1, (LARGURA_TELA // 2 + 80, ALTURA_TELA // 2 + 300))

        fonte_instrucoes = pygame.font.SysFont(None, 30)
        linhas_texto = [
            "No recém-inaugurado zoológico da cidade, um inesperado incidente",
            "causou a quebra da segurança, e todos os animais escaparam dos seus recintos!",
            "Leões, elefantes, zebras, macacos e muitas outras criaturas",
            "agora vagueiam pelo parque, causando caos e diversão inesperada.",
            "",
            "Você e Rodrigo, os únicos cuidadores de plantão, são chamados para salvar o dia!",
            "Vocês têm a missão de capturar e devolver cada animal ao seu lar seguro.",
            "Mas não será uma tarefa fácil!",
            "",
            "O destino do zoológico está nas suas mãos e nas de Rodrigo!",
            "Você está pronto para a aventura?"
        ]

        x_centro = LARGURA_TELA // 2 + 100
        y_inicial = ALTURA_TELA // 2 - 100
        espaco_entre_linhas = 30

        for i, linha in enumerate(linhas_texto):
            texto = fonte_instrucoes.render(linha, True, PRETO)
            texto_rect = texto.get_rect(center=(x_centro, y_inicial + i * espaco_entre_linhas))
            tela.blit(texto, texto_rect)

        pygame.display.flip()
        clock.tick(30)

    if not animando:
        menu_inicial()

def borrar_tela():
    tela.fill(AMARELO)
    pygame.display.update()
    time.sleep(0.2)

def animar_alegria():
    for i in range(10):
        tela.fill(BRANCO)
        desenhar_personagem(50, ALTURA_TELA - 150 - i * 5, "feliz")
        pygame.display.update()
        time.sleep(0.05)
    for i in range(10):
        tela.fill(BRANCO)
        desenhar_personagem(50, ALTURA_TELA - 150 + i * 5, "feliz")
        pygame.display.update()
        time.sleep(0.05)

def desenhar_timer(t, tempo_maximo):
    if t < 4:
        cor_timer = VERMELHO_TIMER
    else:
        cor_timer = VERDE
    pygame.draw.rect(tela, CINZA, (LARGURA_TELA - 160, 20, 150, 30))
    pygame.draw.rect(tela, cor_timer, (LARGURA_TELA - 160, 20, (150 * t) / tempo_maximo, 30))
    timer_text = fonte.render(f"Tempo: {t}", True, BEGE)
    tela.blit(timer_text, (LARGURA_TELA - 150, 18))

def desenhar_seta(x, y, direcao):
    if direcao == 'up':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 10, y + 20), (x + 10, y + 20)])
    elif direcao == 'down':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 10, y - 20), (x + 10, y - 20)])
    elif direcao == 'left':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x + 20, y - 10), (x + 20, y + 10)])
    elif direcao == 'right':
        pygame.draw.polygon(tela, AZUL, [(x, y), (x - 20, y - 10), (x - 20, y + 10)])

def desenhar_caixa_imagem():
    pygame.draw.rect(tela, AZUL, (LARGURA_TELA // 2 - 160, 10, 320, 320), 5)

def tela_final(pontos, multiplicador):
    opcoes = ["Jogar novamente", "Próximo nível", "Voltar aos níveis", "Sair"] if multiplicador < 3 else ["Jogar novamente", "Voltar aos níveis", "Sair"]
    escolha = navegar_opcoes(opcoes, f"Fim do Jogo! Pontuação: {pontos}", cor_titulo=VERDE)
    
    if escolha == 0:
        return "reiniciar"
    elif escolha == 1 and multiplicador < 3:
        return "proximo_nivel"
    elif (escolha == 2 and multiplicador < 3) or (escolha == 1 and multiplicador == 3):
        return "menu_niveis"
    elif (escolha == 3 and multiplicador < 3) or (escolha == 2 and multiplicador == 3):
        pygame.quit()
        exit()

def navegar_opcoes(opcoes, titulo, cor_titulo=AZUL):
    tela.fill(BEGE)
    titulo_texto = fonte_pontos.render(titulo, True, cor_titulo)
    tela.blit(titulo_texto, (LARGURA_TELA // 2 - titulo_texto.get_width() // 2, ALTURA_TELA // 4))
    selecionado = 0
    rodando = True

    while rodando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_DOWN:
                    selecionado = (selecionado + 1) % len(opcoes)
                elif evento.key == pygame.K_UP:
                    selecionado = (selecionado - 1) % len(opcoes)
                elif evento.key == pygame.K_SPACE:
                    return selecionado

        for i, opcao in enumerate(opcoes):
            cor = VERDE if i == selecionado else AZUL
            texto = fonte.render(opcao, True, cor)
            tela.blit(texto, (LARGURA_TELA // 2 - texto.get_width() // 2, ALTURA_TELA // 2 + i * 50))

        pygame.display.flip()
        clock.tick(30)

def menu_inicial():
    opcoes = ["Começar o jogo", "Sair"]
    escolha = navegar_opcoes(opcoes, "Fuga Animal")
    if escolha == 0:
        menu_dificuldade()
    elif escolha == 1:
        pygame.quit()
        exit()

def menu_pause():
    pausado = True
    while pausado:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    pausado = False
                elif event.key == pygame.K_q:
                    pygame.quit()
                    exit()

        opcoes = ["Continuar", "Voltar aos níveis", "Sair"]
        escolha = navegar_opcoes(opcoes, "Jogo Pausado", cor_titulo=AZUL)

        if escolha == 0:
            return "continuar"
        elif escolha == 1:
            return "menu_niveis"
        elif escolha == 2:
            pygame.quit()
            exit()

        return escolha

def menu_dificuldade():
    opcoes = ["Fácil (30 segundos)", "Médio (15 segundos)", "Difícil (5 segundos)"]
    escolha = navegar_opcoes(opcoes, "Escolha a dificuldade")
    if escolha == 0:
        jogo(30, 1)
    elif escolha == 1:
        jogo(15, 2)
    elif escolha == 2:
        jogo(5, 3)

def jogo(tempo_maximo, multiplicador):
    pontos = 0
    rodada = 0
    imagens_usadas = []
    opcoes = []
    ultima_mudanca = 0
    tempo_mudanca = 0
    pausado=False

    while rodada < 10:
        rodada += 1
        rodada_restante = 10 - rodada
        tela.fill(BEGE)

        imagem_atual = random.choice([img for img in imagens if img not in imagens_usadas])
        imagens_usadas.append(imagem_atual)

        palavra_correta = imagem_atual["palavra"]
        opcoes = random.sample([img["palavra"] for img in imagens if img != imagem_atual], 3)
        opcoes.append(palavra_correta)
        random.shuffle(opcoes)

        pontos_texto=desenhaJogo(imagem_atual,opcoes,rodada,rodada_restante,pontos)

        t = tempo_maximo
        tempo_inicial = time.time()
        selecionado = -1
        escolha_confirmada = False
        tecla_pressionada = None
        tempo_pressionamento = 0

        while not escolha_confirmada:
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    return
                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_UP:
                        tecla_pressionada = "up"
                        tempo_pressionamento = pygame.time.get_ticks()
                    elif evento.key == pygame.K_RIGHT:
                        tecla_pressionada = "right"
                        tempo_pressionamento = pygame.time.get_ticks()
                    elif evento.key == pygame.K_DOWN:
                        tempo_pressionamento = pygame.time.get_ticks()
                        tecla_pressionada = "down"
                    elif evento.key == pygame.K_LEFT:
                        tempo_pressionamento = pygame.time.get_ticks()
                        tecla_pressionada = "left"
                    elif evento.key == pygame.K_ESCAPE:
                        tempo_pausa_inicial = time.time()
                        resultado_pause=menu_pause()
                        tempo_pausa_final = time.time()
                        tempo_pausa = tempo_pausa_final - tempo_pausa_inicial
                        tempo_inicial += tempo_pausa
                        tela.fill(BEGE)
                        if resultado_pause == "continuar":
                            desenhaJogo(imagem_atual,opcoes,rodada,rodada_restante,pontos)
                            continue
                        elif resultado_pause == "menu_niveis":
                            menu_dificuldade()

                if evento.type == pygame.KEYUP:
                    if evento.key in [pygame.K_UP, pygame.K_RIGHT, pygame.K_DOWN, pygame.K_LEFT]:
                        tecla_pressionada = None

            if not pausado:
                if tecla_pressionada:
                    if pygame.time.get_ticks() - tempo_pressionamento >= 100:
                        if tecla_pressionada == "up":
                            selecionado = 0
                        elif tecla_pressionada == "right":
                            selecionado = 2
                        elif tecla_pressionada == "down":
                            selecionado = 3
                        elif tecla_pressionada == "left":
                            selecionado = 1
                        tecla_pressionada = None

                t = tempo_maximo - int(time.time() - tempo_inicial)
                if t <= 0:
                    escolha_confirmada = True
                    pontos -= multiplicador
                else:
                    desenhar_timer(t, tempo_maximo)
            else:
                t = tempo_maximo
                tecla_pressionada = None

            if selecionado != -1 and t > 0:
                tempo_percentual = (tempo_maximo - t) / tempo_maximo
                if tempo_percentual <= 0.2:
                    bonus = 4
                elif tempo_percentual <= 0.4:
                    bonus = 3
                elif tempo_percentual <= 0.6:
                    bonus = 2
                elif tempo_percentual <= 0.8:
                    bonus = 1
                else:
                    bonus = 0

                estados = "normal"
                if opcoes[selecionado] == palavra_correta:
                    pontos += multiplicador * bonus
                    som_acerto.play()
                    estados = "feliz"
                    mensagem = "Você acertou ^v^"
                    ultima_mudanca = multiplicador * bonus
                else:
                    pontos -= multiplicador
                    som_erro.play()
                    estados = "triste"
                    mensagem = "Você errou T-T"
                    ultima_mudanca = -multiplicador
                escolha_confirmada = True
                tempo_mudanca = time.time()
                desenhar_personagem(estados, mensagem)

            if time.time() - tempo_mudanca < 1 :
                if ultima_mudanca>0:
                    sinal="+"
                    cor_mud = VERDE
                else:
                    sinal=""
                    cor_mud = VERMELHO
                mudanca = f"{sinal}{ultima_mudanca}"
                mudanca_txt = fonte_pontos.render(mudanca, True, cor_mud)
                pos_pontos=pontos_texto.get_width()+10
                tmnh_txt=mudanca_txt.get_width()
                tela.blit(mudanca_txt,((pos_pontos-tmnh_txt),50))
                
            pygame.display.flip()
            pygame.time.delay(100)

        pygame.display.flip()
        pygame.time.delay(1000)
        clock.tick(30)

    resultado = tela_final(pontos, multiplicador)
    if resultado == "reiniciar":
        jogo(tempo_maximo, multiplicador)
    elif resultado == "proximo_nivel":
        multiplicador += 1
        jogo(tempo_maximo, multiplicador)
    elif resultado == "menu_niveis":
        menu_dificuldade()

def desenhaJogo(imagem_atual,opcoes,rodada,rodada_restante,pontos):
    desenhar_caixa_imagem()
    img = pygame.image.load(imagem_atual["imagem"])
    img = pygame.transform.scale(img, (300, 300))
    tela.blit(img, (LARGURA_TELA // 2 - 150, 10))

    x_centro = LARGURA_TELA // 2
    y_centro = ALTURA_TELA - 150

    opcao_textos = []
    for i, opcao in enumerate(opcoes):
        texto = fonte.render(opcao, True, AZUL)
        opcao_textos.append(texto)

    tela.blit(opcao_textos[0], (x_centro - opcao_textos[0].get_width() // 2, y_centro - 200))
    desenhar_seta(x_centro, y_centro - 150, 'up')

    tela.blit(opcao_textos[1], (x_centro - 200 - opcao_textos[1].get_width() // 2, y_centro - 50))
    desenhar_seta(x_centro - 200, y_centro - 100, 'left')

    tela.blit(opcao_textos[2], (x_centro + 200 - opcao_textos[2].get_width() // 2, y_centro - 50))
    desenhar_seta(x_centro + 200, y_centro - 100, 'right')

    tela.blit(opcao_textos[3], (x_centro - opcao_textos[3].get_width() // 2, y_centro + 50))
    desenhar_seta(x_centro, y_centro + 100, 'down')

    rodada_texto = fonte.render(f"Rodada: {rodada} / 10", True, AZUL)
    restantes_texto = fonte.render(f"Faltam: {rodada_restante} rodadas", True, AZUL)
    pontos_texto = fonte_pontos.render(f"PONTOS: {pontos}", True, AZUL)
    tela.blit(pontos_texto, (10, 10))
    tela.blit(rodada_texto, (10, ALTURA_TELA - 100))
    tela.blit(restantes_texto, (10, ALTURA_TELA - 60))
    return pontos_texto

if __name__ == "__main__":
    tela_inicial()

pygame.quit()
